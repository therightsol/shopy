<?php

function display_proudct_rules( $atts = '' ) {
	
}
