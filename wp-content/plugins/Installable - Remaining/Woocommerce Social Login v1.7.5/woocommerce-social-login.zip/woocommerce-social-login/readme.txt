=== WooCommerce Social Login ===
Author: woothemes, skyverge
Tags: woocommerce
Requires at least: 4.0
Tested up to: 4.4.1
Requires WooCommerce at least: 2.3.6
Tested WooCommerce up to: 2.5.0

One-click registration and login via social networks like Facebook, Google, Twitter and Amazon

See http://docs.woothemes.com/document/woocommerce-social-login/ for full documentation.

== Installation ==

1. Upload the entire 'woocommerce-social-login' folder to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
