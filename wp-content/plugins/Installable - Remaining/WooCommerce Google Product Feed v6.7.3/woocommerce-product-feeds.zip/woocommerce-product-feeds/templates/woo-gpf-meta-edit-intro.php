		<tr>
		  <td colspan="2">
			<h3><?php _e( 'Product Feed Information', 'woocommerce_gpf' ); ?></h3>
			<p><?php _e( 'Only enter values here if you want to over-ride the store defaults for products in this category. You can still override the values here against individual products if you want to.', 'woocommerce_gpf' ); ?></p>
		  </td>
		</tr>
