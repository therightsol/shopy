<td class="forminp">
	<div class="woocommerce_gpf_field_selector_group">
		<input type="checkbox" class="woocommerce_gpf_field_selector" name="woocommerce_gpf_config[product_fields][{key}]" id="woocommerce_gpf_config[product_fields][{key}]" {checked}>
		<label for="woocommerce_gpf_config[product_fields][{key}]">{full_desc}</label>
		{defaults}
	</div>
</td>