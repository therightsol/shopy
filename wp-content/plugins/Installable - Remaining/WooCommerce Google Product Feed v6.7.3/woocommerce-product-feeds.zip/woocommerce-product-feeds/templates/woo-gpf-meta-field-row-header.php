<th>
	<label for="_woocommerce_gpf_data[{key}]">{row_title}<br/>
	{default_text}
	</label>
</th>