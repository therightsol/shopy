<input name="_woocommerce_gpf_data[{key}]" class="woocommerce_gpf_{key} woocommerce-gpf-store-default" value="{value}"{placeholder}>
<script type="text/javascript">
	jQuery( '.woocommerce_gpf_availability_date' ).datepicker( { dateFormat: 'yy-mm-dd', } );
</script>
