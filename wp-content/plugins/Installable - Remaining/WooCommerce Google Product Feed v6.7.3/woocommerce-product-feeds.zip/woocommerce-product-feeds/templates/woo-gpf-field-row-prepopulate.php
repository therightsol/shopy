<p>
	{intro_text}<br>
	<select name="_woocommerce_gpf_prepopulate[{key}]" class="woocommerce-gpf-prepopulate">
		<option value="">{none}</option>
		{options}
	</select>
</p>