<tr valign="top" class="new">
	{header_content}
	{data_content}
</tr>
