<p>
	<label for="_woocommerce_gpf_data[{key}]">{field_description}
		{field_defaults}
	</label>
	<br/>
	{field_input}
</p>