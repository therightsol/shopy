<select name="_woocommerce_gpf_data[{key}]" class="woocommerce-gpf-store-default">
	<option value="">{emptytext}</option>
	<option value="new" {new-selected}><?php _e( 'New', 'woocommerce_gpf' ); ?></option>
	<option value="refurbished" {refurbished-selected}><?php _e( 'Refurbished', 'woocommerce_gpf' ); ?></option>
	<option value="used" {used-selected}><?php _e( 'Used', 'woocommerce_gpf' ); ?></option>
</select>