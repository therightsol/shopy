=== WooCommerce Subscriptions ===
Contributors: prospress, javorszky, jconroy, mattallan, thenbrent
Tags: woocommerce, subscriptions, ecommerce, e-commerce, commerce, wordpress ecommerce
Requires at least: 4.0
Tested up to: 4.3
License: GPLv3
License URI: http://www.gnu.org/licenses/gpl-3.0.html
WC requires at least: 2.3
WC tested up to: 2.4