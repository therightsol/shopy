<?php
/**
 * Product Bundles Functions. Emptiness.
 *
 * @version 4.13.1
 */

// Exit if accessed directly.
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
